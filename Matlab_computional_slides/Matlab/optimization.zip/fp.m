function y = fp(x)
    y = 1/4*(x/2)^(-1/2) - 1/3*((1-x)/3)^(-1/2);
end