
sol = newton(0.5)
fp(sol)
