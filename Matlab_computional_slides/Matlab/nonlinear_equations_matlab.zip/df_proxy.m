function y = df_proxy(x1, x2)
    y = (f(x1) - f(x2))/(x1 - x2);
end