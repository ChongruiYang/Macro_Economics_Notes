function y = df(x)
    y = 1 + 1/x;
end