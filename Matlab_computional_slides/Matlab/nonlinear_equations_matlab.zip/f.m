function y = f(x)
    y = 1 + x + log(x);
end