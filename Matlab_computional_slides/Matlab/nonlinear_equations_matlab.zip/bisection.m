function y = bisection(a, b)

    epsilon = 10^(-6);
    c = (a+b)/2;
    iter = 0;
    
    while (abs(f(c)) > epsilon) 
        iter = iter + 1
        if (f(a)*f(c) < 0)
            b = c;
        elseif (f(b)*f(c) < 0)
            a = c;
        end
        c = (a+b)/2
        f(c)
    end
    
    y = c;
end
    