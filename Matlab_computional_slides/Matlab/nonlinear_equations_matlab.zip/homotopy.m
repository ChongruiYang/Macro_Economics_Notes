function [y,z]=homotopy(x0,t0,stepsize)
%The smaller the step size, the smaller the error, and hence the smaller the tol, but the larger the iteration times
H_t = @(x) x - (2*x - 4 - sin(2*pi*x));
H_x = @(t,x) (1 - t) + t*(2 - 2*pi*cos(2*pi*x));
x = x0;
t = t0;
h = stepsize; 
iter = 0;
eps = h; %tol matches step size h
while abs(t - 1)>eps
    x = x + h*(H_t(x));
    t = t + h*(H_x(t,x));
    iter = iter + 1;
end
y = x;
z = t;
iter %report total iteration times