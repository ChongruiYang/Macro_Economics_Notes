function y = newton(x0)

    epsilon = 10^(-6);
    x1 = x0;
    x2 = x1 - f(x1)/df(x1);
    iter = 0;
    
    while (abs(x1 - x2) > epsilon * (1 + abs(x2)) && iter < 1000) 
        iter = iter + 1
        x1 = x2
        x2 = x1 - f(x1)/df(x1)
        f(x2)
    end
    
    y = x2;
end
    