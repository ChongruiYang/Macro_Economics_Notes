sol1 = bisection(-1, 1)
sol2 = newton(0.5)
sol3 = secant(0.5, -0.5)
