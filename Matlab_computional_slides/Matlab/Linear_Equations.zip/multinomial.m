function y = multinomial(A, x)

[~, N] = size(A);

sum = A(N);
for i = 1 : N-1
    j = N-i;
    sum = A(j) + sum*x;
end

y = sum;