function y = gaussseidel1(p0, q0, n)

p = zeros(n+1, 1);
q = zeros(n+1, 1);

p(1) = p0;
q(1) = q0;

for i = 1 : n
    q(i+1) = 1 + 0.5*p(i);
    p(i+1) = 10 - q(i+1);
end

y = [p, q];