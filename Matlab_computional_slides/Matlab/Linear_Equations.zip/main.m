A = [1 2 3 4];
x = 2;
% 1 + 2*x + 3*x^2 + 4*x^3
multinomial(A, x)

gaussjacobi1(4, 1, 5)
gaussjacobi1(4, 1, 20)

gaussseidel1(4, 1, 5)
gaussseidel1(4, 1, 20)

gaussseidel2(10, 0, 10)
sor2(10, 0, 0.75, 10)

gaussseidel3(0, 0, 20)
sor3(0, 0, 1.5, 20)