function y = sor2(p0, q0, w, n)

p = zeros(n+1, 1);
q = zeros(n+1, 1);

p(1) = p0;
q(1) = q0;

for i = 1 : n
    q(i+1) = w*(p(i)/2 - 3) + (1-w)*q(i);
    p(i+1) = w*(21 - 3*q(i+1)) + (1-w)*p(i);
end

y = [p, q];