function y = gaussseidel3(p10, p20, n)

p1 = zeros(n+1, 1);
p2 = zeros(n+1, 1);

p1(1) = p10;
p2(1) = p20;

for i = 1 : n
    p1(i+1) = 1 + 0.75*p2(i);
    p2(i+1) = 2 + 0.8*p1(i+1);
end

y = [p1, p2];