function y = gaussseidel2(p0, q0, n)

p = zeros(n+1, 1);
q = zeros(n+1, 1);

p(1) = p0;
q(1) = q0;

for i = 1 : n
    q(i+1) = p(i)/2 - 3;
    p(i+1) = 21 - 3*q(i+1);
end

y = [p, q];